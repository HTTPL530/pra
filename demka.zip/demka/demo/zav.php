<?php
$departure_address = $delivery_address = $date = $time = $cargo_weight = $cargo_type = $cargo_dimensions = "";
$errors = [];

// Предполагается, что вы уже начали сессию
session_start();
$phone = $_SESSION['phone'] ?? ''; // Получаем номер телефона из сессии

require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $departure_address = trim($_POST["departure_address"] ?? '');
    $delivery_address = trim($_POST["delivery_address"] ?? '');
    $date = trim($_POST["date"] ?? '');
    $time = trim($_POST["time"] ?? '');
    $cargo_weight = trim($_POST["cargo_weight"] ?? '');
    $cargo_type = trim($_POST["cargo_type"] ?? '');
    $cargo_dimensions = trim($_POST["cargo_dimensions"] ?? '');

    if ($departure_address === '') {
        $errors['departure_address'] = "Адрес отправления обязателен.";
    }
    if ($delivery_address === '') {
        $errors['delivery_address'] = "Адрес доставки обязателен.";
    }
    if ($date === '') {
        $errors['date'] = "Дата отправки обязательна.";
    }
    if ($time === '') {
        $errors['time'] = "Время отправки обязательно.";
    }
    if ($cargo_weight === '') {
        $errors['cargo_weight'] = "Вес груза обязателен.";
    }
    if ($cargo_type === '') {
        $errors['cargo_type'] = "Тип груза обязателен.";
    }
    if ($cargo_dimensions === '') {
        $errors['cargo_dimensions'] = "Габариты груза обязательны.";
    }

    if (empty($errors)) {
        $sql = "INSERT INTO public.shipments (shipment_date, shipment_time, cargo_weight, cargo_type, departure_address, delivery_address, cargo_dimensions, phone_number) 
                VALUES (:date, :time, :cargo_weight, :cargo_type, :departure_address, :delivery_address, :cargo_dimensions, :phone)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':date' => $date,
            ':time' => $time,
            ':cargo_weight' => $cargo_weight,
            ':cargo_type' => $cargo_type,
            ':departure_address' => $departure_address,
            ':delivery_address' => $delivery_address,
            ':cargo_dimensions' => $cargo_dimensions,
            ':phone' => $phone
        ]);
        header("Location: lk.php?success=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Формирование заявки</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0; padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }
        header img {
            height: 40px;
            margin-right: 10px;
        }
        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .form-container {
            width: 400px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px #fff;
        }
        h2 {
            text-align: center;
            color: white;
            margin-top: 0;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"],
        select {
            width: 96%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 15px;
        }
        input[type="submit"] {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 15px;
            cursor: pointer;
            width: 100%;
            display: block;
            margin: 0 auto;
        }
        input[type="submit"]:hover {
            background-color: #FF813D94;
        }
        .error {
            color: red;
            font-size: 0.9em;
            margin-top: -8px;
            margin-bottom: 10px;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
            color: white;
        }
        .login-link a {
            color: #FF813D;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Логотип" />
    <h1>Мой Не Сам</h1>
</header>

<div class="container">
    <div class="form-container">
        <h2>Формирование заявки</h2>
        <form method="post" action="">
            <input type="text" name="departure_address" placeholder="Адрес отправления" value="<?= htmlspecialchars($departure_address) ?>">
            <div class="error"><?= $errors['departure_address'] ?? '' ?></div>

            <input type="text" name="delivery_address" placeholder="Адрес доставки" value="<?= htmlspecialchars($delivery_address) ?>">
            <div class="error"><?= $errors['delivery_address'] ?? '' ?></div>

            <input type="date" name="date" value="<?= htmlspecialchars($date) ?>">
            <div class="error"><?= $errors['date'] ?? '' ?></div>

            <input type="time" name="time" value="<?= htmlspecialchars($time) ?>">
            <div class="error"><?= $errors['time'] ?? '' ?></div>

            <input type="text" name="cargo_weight" placeholder="Вес груза" value="<?= htmlspecialchars($cargo_weight) ?>">
            <div class="error"><?= $errors['cargo_weight'] ?? '' ?></div>

            <select name="cargo_type">
                <option value="">Выберите тип груза</option>
                <option value="хрупкое" <?= $cargo_type === "хрупкое" ? 'selected' : '' ?>>Хрупкое</option>
                <option value="скоропортящаяся" <?= $cargo_type === "скоропортящаяся" ? 'selected' : '' ?>>Скоропортящаяся</option>
                <option value="требуется рефрижератор" <?= $cargo_type === "требуется рефрижератор" ? 'selected' : '' ?>>Требуется рефрижератор</option>
                <option value="животные" <?= $cargo_type === "животные" ? 'selected' : '' ?>>Животные</option>
                <option value="жидкость" <?= $cargo_type === "жидкость" ? 'selected' : '' ?>>Жидкость</option>
                <option value="мебель" <?= $cargo_type === "мебель" ? 'selected' : '' ?>>Мебель</option>
                <option value="мусор" <?= $cargo_type === "мусор" ? 'selected' : '' ?>>Мусор</option>
            </select>
            <div class="error"><?= $errors['cargo_type'] ?? '' ?></div>

            <input type="text" name="cargo_dimensions" placeholder="Габариты груза" value="<?= htmlspecialchars($cargo_dimensions) ?>">
            <div class="error"><?= $errors['cargo_dimensions'] ?? '' ?></div>

            <input type="submit" value="Отправить заявку">
        </form>
        <div class="login-link">
            <a href="lk.php">Войти в личный кабинет</a>
        </div>
    </div>
</div>

<script>
    <?php if (isset($_GET['success'])): ?>
        alert('Заявка отправлена! Спасибо за вашу заявку. Мы свяжемся с вами в ближайшее время.');
    <?php endif; ?>
</script>
</body>
</html>
