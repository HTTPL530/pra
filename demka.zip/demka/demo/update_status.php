<?php
session_start();
require_once 'db.php';

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещен.']);
    exit;
}

// Получаем данные из POST-запроса
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['application_id'], $data['status'])) {
    $application_id = $data['application_id'];
    $status = $data['status'];
    $cancel_reason = isset($data['cancel_reason']) ? $data['cancel_reason'] : null;

    // Обновляем статус в базе данных
    $sql = "UPDATE public.shipments SET status = :status" . ($cancel_reason ? ", cancel_reason = :cancel_reason" : "") . " WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    
    // Привязываем параметры
    $params = [
        ':status' => $status,
        ':id' => $application_id
    ];
    
    if ($cancel_reason) {
        $params[':cancel_reason'] = $cancel_reason;
    }

    if ($stmt->execute($params)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Не удалось обновить статус.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Некорректные данные.']);
}
?>