<?php
session_start();
require_once 'bd.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: avtor.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Получаем все заявки из таблицы shipments
$sql = "SELECT shipment_date, shipment_time, cargo_weight, cargo_type, departure_address, delivery_address, cargo_dimensions, status FROM public.shipments WHERE phone_number IN (SELECT phone FROM public.users WHERE id = :user_id)";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>История заявок</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 40px;
            margin-right: 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .history-container {
            width: 600px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255 255 255);
        }

        h2 {
            text-align: center;
            color: white;
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
            color: white;
        }

        th {
            background-color: #FF813D;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 15px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .button:hover {
            background-color: #FF813D94;
        }

        footer {
            background-color: #FF813D;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.png" alt="Логотип" />
        <h1>Мой Не Сам</h1>
    </header>

    <div class="container">
        <div class="history-container">
            <h2>История заявок</h2>
            <table>
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Время</th>
                        <th>Вес груза</th>
                        <th>Тип груза</th>
                        <th>Адрес отправления</th>
                        <th>Адрес доставки</th>
                        <th>Размеры груза</th>
                        <th>Статус</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="8" style="color: white; text-align: center;">Нет заявок.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><?= htmlspecialchars($app['shipment_date']) ?></td>
                                <td><?= htmlspecialchars($app['shipment_time']) ?></td>
                                <td><?= htmlspecialchars($app['cargo_weight']) ?> кг</td>
                                <td><?= htmlspecialchars($app['cargo_type']) ?></td>
                                <td><?= htmlspecialchars($app['departure_address']) ?></td>
                                <td><?= htmlspecialchars($app['delivery_address']) ?></td>
                                <td><?= htmlspecialchars($app['cargo_dimensions']) ?></td>
                                <td><?= htmlspecialchars($app['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="button-container">
                <a href="zav.php" class="button">Создать новую заявку</a>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date("Y") ?> Ваша компания. Все права защищены.</p>
    </footer>
</body>

</html>
