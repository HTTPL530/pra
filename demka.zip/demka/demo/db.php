<?php
// db.php

$host = '172.27.14.102'; // или ваш хост
$db = 'user06'; // имя вашей базы данных
$user = 'user06'; // ваше имя пользователя
$pass = 'NKSX4NHH'; // ваш пароль

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Ошибка подключения: " . $e->getMessage();
    exit;
}
?>



