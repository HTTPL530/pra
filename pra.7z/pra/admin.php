<?php
session_start();
require_once 'db.php';

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: avtor.php"); // Перенаправляем на страницу авторизации, если не авторизован
    exit;
}

// Получаем все заявки из базы данных
$sql = "SELECT * FROM piblic.applications";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Все заявки</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .applications-container {
            width: 1000px;
            /* Увеличено для более широкой таблицы */
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
            color: white;
        }

        th {
            background-color: #FF813D;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 15px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #FF813D94;
        }

        .cancel-reason {
            margin-left: 10px;
            /* Добавлено для отступа */
            padding: 5px;
            /* Добавлено для отступа */
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 200px;
            /* Задаем ширину поля ввода */
            display: none;
            /* Скрыто по умолчанию */
            transition: border-color 0.3s ease;
        }

        .cancel-reason:focus {
            border-color: #FF813D;
            /* Цвет рамки при фокусе */
            outline: none;
            /* Убираем стандартный контур */
        }

        .update-status-button {
            background-color: #FF813D;
            /* Зеленый цвет для кнопки обновления */
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 10px;
            /* Отступ между селектором и кнопкой */
        }

        .update-status-button:hover {
            background-color: #FF813D;
            /* Темнее зеленый при наведении */
        }
    </style>
</head>

<body>
    <header>
        <h1>Панель администратора</h1>
    </header>

    <div class="container">
        <div class="applications-container">
            <h2>Все заявки</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Адрес</th>
                        <th>Телефон</th>
                        <th>Дата</th>
                        <th>Время</th>
                        <th>Услуга</th>
                        <th>Другие услуги</th>
                        <th>Способ оплаты</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="10">Нет заявок.</td>
                        </tr>
                    <?php else: ?>
                        <?php
                        foreach ($applications as $application): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($application['id']); ?></td>
                                <td><?php echo htmlspecialchars($application['address']); ?></td>
                                <td><?php echo htmlspecialchars($application['phone']); ?></td>
                                <td><?php echo htmlspecialchars($application['date']); ?></td>
                                <td><?php echo htmlspecialchars($application['time']); ?></td>
                                <td><?php echo htmlspecialchars($application['service']); ?></td>
                                <td><?php echo htmlspecialchars($application['other_service']); ?></td>
                                <td><?php echo htmlspecialchars($application['payment_method']); ?></td>
                                <td>
                                    <select name="status" class="status-select" data-id="<?php echo $application['id']; ?>">
                                        <option value="в работе" <?php if ($application['status'] == 'в работе')
                                            echo 'selected'; ?>>В работе</option>
                                        <option value="выполнено" <?php if ($application['status'] == 'выполнено')
                                            echo 'selected'; ?>>Выполнено</option>
                                        <option value="отменено" <?php if ($application['status'] == 'отменено')
                                            echo 'selected'; ?>>Отменено</option>
                                    </select>
                                    <input type="text" name="cancel_reason" placeholder="Причина отмены" class="cancel-reason">
                                    <button class="update-status-button">Обновить статус</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer style="background-color: #FF813D; color: white; text-align: center; padding: 10px 0;">
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

    <script>
        // Показать поле для ввода причины отмены, если выбрано "отменено"
        document.querySelectorAll('.status-select').forEach(function (select) {
            select.addEventListener('change', function () {
                const cancelReasonInput = this.closest('td').querySelector('.cancel-reason');
                if (this.value === 'отменено') {
                    cancelReasonInput.style.display = 'inline';
                } else {
                    cancelReasonInput.style.display = 'none';
                    cancelReasonInput.value = ''; // Очистить поле, если статус не "отменено"
                }
            });
        });

        // Обработка нажатия кнопки "Обновить статус"
        document.querySelectorAll('.update-status-button').forEach(function (button) {
            button.addEventListener('click', function () {
                const row = this.closest('tr');
                const select = row.querySelector('.status-select');
                const cancelReasonInput = row.querySelector('.cancel-reason');

                const applicationId = select.getAttribute('data-id');
                const status = select.value;
                const cancelReason = cancelReasonInput.style.display === 'inline' ? cancelReasonInput.value : '';

                fetch('update_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        application_id: applicationId,
                        status: status,
                        cancel_reason: cancelReason
                    })
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Статус обновлен успешно!');
                        } else {
                            alert('Ошибка при обновлении статуса: ' + data.message);
                        }
                    })
                    .catch((error) => {
                        console.error('Ошибка:', error);
                    });
            });
        });
    </script>
</body>

</html>