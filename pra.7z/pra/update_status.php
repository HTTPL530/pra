<?php
session_start();
require_once 'db.php';

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'Не авторизован']);
    exit;
}

// Получаем данные из запроса
$data = json_decode(file_get_contents('php://input'), true);
$application_id = $data['application_id'];
$status = $data['status'];
$cancel_reason = $data['cancel_reason'];

// Обновление статуса заявки в базе данных
$sql = "UPDATE piblic.applications SET status = :status, cancel_reason = :cancel_reason WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':status', $status);
$stmt->bindParam(':cancel_reason', $cancel_reason);
$stmt->bindParam(':id', $application_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Ошибка обновления статуса']);
}
?>

