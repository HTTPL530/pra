<?php
// Подключаем файл db.php
require_once 'db.php';

$username = $password = "";
$errors = [];

// Обработка данных формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    if (empty($username)) {
        $errors['username'] = "Логин обязателен.";
    }
    if (empty($password)) {
        $errors['password'] = "Пароль обязателен.";
    }

    // Если нет ошибок, проверяем данные
    if (empty($errors)) {
        // Проверка на администратора
        if ($username === 'adminka' && $password === 'password') {
            session_start();
            $_SESSION['admin_logged_in'] = true; // Сохраняем информацию о входе администратора
            header("Location: admin.php"); // Перенаправляем на страницу администратора
            exit;
        }

        // Подготовка SQL-запроса для получения пользователя
        $sql = "SELECT * FROM piblic.users WHERE username = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Проверяем, существует ли пользователь и совпадает ли пароль
        if ($user && password_verify($password, $user['password'])) {
            // Успешная авторизация
            session_start();
            $_SESSION['user_id'] = $user['id']; // Сохраняем ID пользователя в сессии
            header("Location: lk.php"); // Перенаправляем на страницу приветствия
            exit;
        } else {
            $errors['login'] = "Неверный логин или пароль.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 40px;
            margin-right: 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            width: 400px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        input[type="text"],
        input[type="password"] {
            width: 96%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 15px;
        }

        input[type="submit"] {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 15px;
            cursor: pointer;
            width: 100%;
            display: block;
            margin: 0 auto;
        }

        input[type="submit"]:hover {
            background-color: #FF813D94;
        }

        .error {
            color: red;
            font-size: 0.9em;
        }

        .register-link {
            text-align: center;
            margin-top: 15px;
            color: white;
        }

        .register-link a {
            color: #FF813D;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <header>
        <img src="logo.png" alt="Логотип">
        <h1>Мой Не Сам</h1>
    </header>

    <div class="container">
        <div class="form-container">
            <h2>Авторизация</h2>
            <form method="post" action="">
                <input type="text" name="username" placeholder="Логин" value="<?php echo htmlspecialchars($username); ?>">
                
                <div class="error"><?php echo isset($errors['username']) ? $errors['username'] : ''; ?></div>

                <input type="password" name="password" placeholder="Пароль">
                <div class="error"><?php echo isset($errors['password']) ? $errors['password'] : ''; ?></div>
                <div class="error"><?php echo isset($errors['login']) ? $errors['login'] : ''; ?></div>

                <input type="submit" value="Войти">
            </form>
            <div class="register-link">
                <p>Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>

    <footer style="background-color: #FF813D; color: white; text-align: center; padding: 10px 0;">
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

</body>

</html>
