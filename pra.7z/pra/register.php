<?php
// Подключаем файл db.php
require_once 'db.php';

$username = $email = $password = $fullname = $phone = "";
$errors = [];

// Обработка данных формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $fullname = trim($_POST["fullname"]);
    $phone = trim($_POST["phone"]);

    if (empty($username)) {
        $errors['username'] = "Логин обязателен.";
    }
    if (empty($fullname) || !preg_match("/^[А-Яа-яЁё\s]+$/u", $fullname)) {
        $errors['fullname'] = "ФИО должно содержать только кириллицу и пробелы.";
    }
    if (empty($phone) || !preg_match("/\+7$\d{3}$-\d{3}-\d{2}-\d{2}$/", $phone)) {
        $error['phone'] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX.";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Некорректный адрес электронной почты.";
    }
    if (empty($password) || strlen($password) < 6) {
        $errors['password'] = "Пароль должен содержать минимум 6 символов.";
    }

    // Если нет ошибок, можно заносить пользователя в базу данных
    if (empty($errors)) {
        // Хешируем пароль перед сохранением
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Подготовка SQL-запроса для вставки данных
        $sql = "INSERT INTO piblic.users (username, fullname, phone, email, password) VALUES (:username, :fullname, :phone, :email, :password)";
        $stmt = $pdo->prepare($sql);

        // Привязываем параметры и выполняем запрос
        $stmt->execute([
            ':username' => $username,
            ':fullname' => $fullname,
            ':phone' => $phone,
            ':email' => $email,
            ':password' => $hashed_password,
        ]);

        // После успешной регистрации можно перенаправить пользователя
        header("Location: avtor.php"); // Перенаправляем на avtor.php
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 40px;
            margin-right: 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            width: 400px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: 96%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 15px;
        }


        input[type="submit"] {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 15px;
            cursor: pointer;
            width: 100%;
            display: block;
            margin: 0 auto;
        }

        input[type="submit"]:hover {
            background-color: #FF813D94;
        }

        .error {
            color: red;
            font-size: 0.9em;
        }

        .login-link {
            text-align: center;
            margin-top: 15px;
            color: white;
        }

        .login-link a {
            color: #FF813D;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.png" alt="Логотип">
        <h1>Мой Не Сам</h1>
    </header>

    <div class="container">
        <div class="form-container">
            <h2>Регистрация</h2>
            <form method="post" action="">
                <input type="text" name="username" placeholder="Логин"
                    value="<?php echo htmlspecialchars($username); ?>">
                <div class="error"><?php echo isset($errors['username']) ? $errors['username'] : ''; ?></div>

                <input type="text" name="fullname" placeholder="ФИО" value="<?php echo htmlspecialchars($fullname); ?>">
                <div class="error"><?php echo isset($errors['fullname']) ? $errors['fullname'] : ''; ?></div>

                <input type="tel" name="phone" placeholder="Телефон (+7(XXX)-XXX-XX-XX)"
                    value="<?php echo htmlspecialchars($phone); ?>" oninput="formatPhone(this)">
                <div class="error"><?php echo isset($errors['phone']) ? $errors['phone'] : ''; ?></div>

                <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>">
                <div class="error"><?php echo isset($errors['email']) ? $errors['email'] : ''; ?></div>

                <input type="password" name="password" placeholder="Пароль">
                <div class="error"><?php echo isset($errors['password']) ? $errors['password'] : ''; ?></div>

                <input type="submit" value="Зарегистрироваться">
            </form>
            <div class="login-link">
                <p>Уже есть аккаунт? <a href="avtor.php">Войти</a></p>
            </div>
        </div>
    </div>

    <footer style="background-color: #FF813D; color: white; text-align: center; padding: 10px 0;">
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

    <script>
        function formatPhone(input) {
            // Удаляем все символы, кроме цифр
            let value = input.value.replace(/\D/g, '');

            // Проверяем, начинается ли номер с 7
            if (value.length > 0 && value[0] !== '7') {
                value = '7' + value; // добавляем 7 в начале
            }

            // Форматируем номер
            const formatted = value.replace(/(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})/, '+7(\$2)-\$3-\$4-\$5');

            // Ограничиваем длину ввода
            if (formatted.length > 17) {
                input.value = formatted.substring(0, 17);
            } else {
                input.value = formatted;
            }
        }
    </script>

</body>

</html>