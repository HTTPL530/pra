<?php
session_start();
require_once 'db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header("Location: avtor.php"); // Перенаправляем на страницу авторизации, если не авторизован
    exit;
}

// Получаем ID пользователя из сессии
$user_id = $_SESSION['user_id'];

// Получаем номер телефона пользователя из базы данных
$sql = "SELECT phone FROM piblic.users WHERE id = :user_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Если пользователь не найден, перенаправляем
    header("Location: avtor.php");
    exit;
}

$user_phone = $user['phone'];

// Получаем историю заявок из базы данных по номеру телефона
$sql = "SELECT date, service, status, cancel_reason FROM piblic.applications WHERE phone = :user_phone";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_phone' => $user_phone]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>История заявок</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 40px;
            margin-right: 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .history-container {
            width: 600px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
            color: white;
        }

        th {
            background-color: #FF813D;
        }

        .cancel-reason {
            max-width: 200px; /* Установите желаемую максимальную ширину */
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 15px;
            cursor: pointer;
            text-decoration: none;
        }

        .button:hover {
            background-color: #FF813D94;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.png" alt="Логотип">
        <h1>Мой Не Сам</h1>
    </header>

    <div class="container">
        <div class="history-container">
            <h2>История заявок</h2>
            <table>
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Услуга</th>
                        <th>Статус</th>
                        <th>Причина отмены</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="4">Нет заявок.</td>
                        </tr>
                    <?php else: ?>

                        <?php foreach ($applications as $application): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($application['date']); ?></td>
                                <td><?php echo htmlspecialchars($application['service']); ?></td>
                                <td><?php echo htmlspecialchars($application['status']); ?></td>
                                <td class="cancel-reason"><?php echo htmlspecialchars($application['cancel_reason'] ?? '—'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="button-container">
                <a href="zav.php" class="button">Создать новую заявку</a>
            </div>
        </div>
    </div>

    <footer style="background-color: #FF813D; color: white; text-align: center; padding: 10px 0;">
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

</body>

</html>
