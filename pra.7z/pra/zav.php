<?php
$address = $phone = $date = $time = $service = $other_service = $payment_method = "";
$errors = [];

require_once 'db.php';

// Обработка данных формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $address = trim($_POST["address"]);
    $phone = trim($_POST["phone"]);
    $date = trim($_POST["date"]);
    $time = trim($_POST["time"]);
    $service = trim($_POST["service"]);
    $other_service = trim($_POST["other_service"]);
    $payment_method = trim($_POST["payment_method"]);

    // Валидация данных
    if (empty($address)) {
        $errors['address'] = "Адрес обязателен.";
    }
    if (empty($phone) || !preg_match("/^\+7$\d{3}$-\d{3}-\d{2}-\d{2}$/", $phone)) {
        $error['phone'] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX.";
    }
    if (empty($date)) {
        $errors['date'] = "Дата получения услуги обязательна.";
    }
    if (empty($time)) {
        $errors['time'] = "Время получения услуги обязательно.";
    }
    if (empty($service) && empty($other_service)) {
        $errors['service'] = "Выберите вид услуги или укажите иную.";
    }
    if (empty($payment_method)) {
        $errors['payment_method'] = "Выберите тип оплаты.";
    }

    // Если нет ошибок, сохраняем данные в базу данных
    if (empty($errors)) {
        $sql = "INSERT INTO piblic.applications (address, phone, date, time, service, other_service, payment_method) 
                VALUES (:address, :phone, :date, :time, :service, :other_service, :payment_method)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':address' => $address,
            ':phone' => $phone,
            ':date' => $date,
            ':time' => $time,
            ':service' => $service,
            ':other_service' => $other_service,
            ':payment_method' => $payment_method
        ]);

        // После успешной отправки можно перенаправить пользователя
        header("Location: lk.php"); // Перенаправляем на страницу с параметром успеха
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Формирование заявки</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 40px;
            margin-right: 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            width: 400px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        input[type="text"],
        input[type="tel"],
        input[type="date"],
        input[type="time"],
        select {
            width: 96%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 15px;
        }

        input[type="submit"] {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 15px;
            cursor: pointer;
            width: 100%;
            display: block;
            margin: 0 auto;
        }

        input[type="submit"]:hover {
            background-color: #FF813D94;
        }

        .error {
            color: red;
            font-size: 0.9em;
        }

        .login-link {
            text-align: center;
            margin-top: 15px;
            color: white;
        }

        .login-link a {
            color: #FF813D;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        /* Стиль для модального окна */
        #successModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        #successModal div {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            width: 300px;
            text-align: center;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.png" alt="Логотип">
        <h1>Мой Не Сам</h1>
    </header>

    <div class="container">
        <div class="form-container">
            <h2>Формирование заявки</h2>
            <form method="post" action="">
                <input type="text" name="address" placeholder="Адрес" value="<?php echo htmlspecialchars($address); ?>">
                <div class="error"><?php echo isset($errors['address']) ? $errors['address'] : ''; ?></div>

                <input type="tel" name="phone" placeholder="Телефон (+7(XXX)-XXX-XX-XX)"
                    value="<?php echo htmlspecialchars($phone); ?>" oninput="formatPhone(this)">
                <div class="error"><?php echo isset($errors['phone']) ? $errors['phone'] : ''; ?></div>

                <input type="date" name="date" value="<?php echo htmlspecialchars($date); ?>">
                <div class="error"><?php echo isset($errors['date']) ? $errors['date'] : ''; ?></div>

                <input type="time" name="time" value="<?php echo htmlspecialchars($time); ?>">
                <div class="error"><?php echo isset($errors['time']) ? $errors['time'] : ''; ?></div>

                <select name="service" onchange="handleServiceChange(this)">
                    <option value="">Выберите услугу</option>
                    <option value="общий клининг" <?php echo ($service == "общий клининг") ? 'selected' : ''; ?>>Общий
                        клининг</option>
                    <option value="генеральная уборка" <?php echo ($service == "генеральная уборка") ? 'selected' : ''; ?>>Генеральная уборка</option>
                    <option value="послестроительная уборка" <?php echo ($service == "послестроительная уборка") ? 'selected' : ''; ?>>Послестроительная уборка</option>
                    <option value="химчистка" <?php echo ($service == "химчистка") ? 'selected' : ''; ?>>Химчистка ковров
                        и мебели</option>
                    <option value="иная" <?php echo ($service == "иная") ? 'selected' : ''; ?>>Иная услуга</option>
                </select>
                <div class="error"><?php echo isset($errors['service']) ? $errors['service'] : ''; ?></div>

                <div id="other_service_container"
                    style="display: <?php echo ($service == "иная") ? 'block' : 'none'; ?>;">
                    <input type="text" name="other_service" placeholder="Опишите иную услугу"
                        value="<?php echo htmlspecialchars($other_service); ?>">
                </div>

                <div>
                    <label>
                        <input type="radio" name="payment_method" value="наличные" <?php echo ($payment_method == "наличные") ? 'checked' : ''; ?>> Наличные
                    </label>
                    <label>
                       
                        <input type="radio" name="payment_method" value="карта" <?php echo ($payment_method == "карта") ? 'checked' : ''; ?>> Карта
                    </label>
                </div>
                <div class="error"><?php echo isset($errors['payment_method']) ? $errors['payment_method'] : ''; ?></div>

                <input type="submit" value="Отправить заявку">
            </form>
            <div class="login-link">
                <a href="lk.php">Войти в личный кабинет</a>
            </div>
        </div>
    </div>

    <!-- Модальное окно -->
    <div id="successModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.5); z-index:1000;">
        <div style="background-color:white; margin:15% auto; padding:20px; width:300px; text-align:center; border-radius:10px;">
            <h2>Заявка отправлена!</h2>
            <p>Спасибо за вашу заявку. Мы свяжемся с вами в ближайшее время.</p>
            <button onclick="closeModal()">Закрыть</button>
        </div>
    </div>

    <script>
        function closeModal() {
            document.getElementById("successModal").style.display = "none";
        }

        // Отображение модального окна при успешной отправке
        <?php if (isset($_GET['success'])): ?>
            document.getElementById("successModal").style.display = "block";
        <?php endif; ?>
        function formatPhone(input) {
            // Удаляем все символы, кроме цифр
            let value = input.value.replace(/\D/g, '');

            // Проверяем, начинается ли номер с 7
            if (value.length > 0 && value[0] !== '7') {
                value = '7' + value; // добавляем 7 в начале
            }

            // Форматируем номер
            const formatted = value.replace(/(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})/, '+7(\$2)-\$3-\$4-\$5');

            // Ограничиваем длину ввода
            if (formatted.length > 17) {
                input.value = formatted.substring(0, 17);
            } else {
                input.value = formatted;
            }
        }
    </script>
</body>
</html>
