<?php
require_once 'db.php';
session_start();

$username = $password = "";
$errors = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? '');
    $password = trim($_POST["password"] ?? '');

    if ($username === '') {
        $errors['username'] = "Логин обязателен.";
    }
    if ($password === '') {
        $errors['password'] = "Пароль обязателен.";
    }

    if (empty($errors)) {
        if ($username === 'admin' && $password === 'gruzovik2024') {
            $_SESSION['admin_logged_in'] = true;
            header("Location: adminka.php");
            exit;
        } 

        $sql = "SELECT * FROM public.users WHERE username = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['phone'] = $user['phone']; // Сохраняем номер телефона в сессии
            header("Location: lk.php");
            exit;
        } else {
            $errors['login'] = "Неверный логин или пароль.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Авторизация</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333;
        }

        header {
            background-color: #4a90e2;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        header img {
            height: 50px;
            margin-right: 20px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }

        .form-container {
            width: 400px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            color: #4a90e2;
            margin-bottom: 20px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 94%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #4a90e2;
            outline: none;
        }

        input[type="submit"] {
            background-color: #4a90e2;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin: 20px 0;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #357ab8;
        }

        .error {
            color: red;
            font-size: 0.9em;
            min-height: 1.2em;
        }

        .register-link {
            text-align: center;
            margin-top: 15px;
            color: #333;
        }

        .register-link a {
            color: #4a90e2;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #4a90e2;
            color: white;
            text-align: center;
            padding: 15px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>

<body>

    <header>
        <img src="logo.png" alt="Логотип" />
        <h1>Авторизация</h1>
    </header>

    <div class="container">
        <div class="form-container">
            <h2>Вход в аккаунт</h2>
            <form method="post" action="">
                <input type="text" name="username" placeholder="Логин" value="<?php echo htmlspecialchars($username); ?>" />
                <div class="error"><?php echo $errors['username'] ?? ''; ?></div>

                <input type="password" name="password" placeholder="Пароль" />
                <div class="error"><?php echo $errors['password'] ?? ''; ?></div>

                <div class="error"><?php echo $errors['login'] ?? ''; ?></div>

                <input type="submit" value="Войти" />
            </form>
            <div class="register-link">
                <p>Нет аккаунта? <a href="registration.php">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

</body>

</html>
