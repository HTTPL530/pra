<?php
session_start();
require_once 'db.php';

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: avtor.php"); // Перенаправляем на страницу авторизации, если не авторизован
    exit;
}

// Получаем все заявки из базы данных
$sql = "SELECT * FROM public.reservations"; // Изменено на reservations
$stmt = $pdo->prepare($sql);
$stmt->execute();
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Все заявки</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #FF813D;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .applications-container {
            width: 1000px;
            padding: 20px;
            background-color: rgba(255, 149, 92, 0.75);
            border-radius: 15px;
            box-shadow: 0 0 10px rgb(255, 255, 255);
        }

        h2 {
            text-align: center;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
            color: white;
        }

        th {
            background-color: #FF813D;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 15px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #FF813D94;
        }

        .update-status-button {
            background-color: #FF813D;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 10px;
        }

        .update-status-button:hover {
            background-color: #FF813D;
        }
    </style>
</head>

<body>
    <header>
        <h1>Панель администратора</h1>
    </header>

    <div class="container">
        <div class="applications-container">
            <h2>Все заявки</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Дата бронирования</th>
                        <th>Время бронирования</th>
                        <th>Количество гостей</th>
                        <th>Телефон</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="7">Нет заявок.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($applications as $application): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($application['id']); ?></td>
                                <td><?php echo htmlspecialchars($application['reservation_date']); ?></td>
                                <td><?php echo htmlspecialchars($application['reservation_time']); ?></td>
                                <td><?php echo htmlspecialchars($application['guest_count']); ?></td>
                                <td><?php echo htmlspecialchars($application['phone']); ?></td>
                                <td>
                                    <select name="status" class="status-select" data-id="<?php echo $application['id']; ?>">
                                        <option value="новая" <?php if ($application['status'] == 'новая') echo 'selected'; ?>>Новая</option>
                                        <option value="в работе" <?php if ($application['status'] == 'в работе') echo 'selected'; ?>>Посещение состоялось</option>
                                        <option value="выполнено" <?php if ($application['status'] == 'выполнено') echo 'selected'; ?>>Отменено</option>
                                    </select>
                                </td>
                                <td>
                                    <button class="update-status-button">Обновить статус</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer style="background-color: #FF813D; color: white; text-align: center; padding: 10px 0;">
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

    <script>
        // Обработка нажатия кнопки "Обновить статус"
        document.querySelectorAll('.update-status-button').forEach(function(button) {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const select = row.querySelector('.status-select');

                const applicationId = select.getAttribute('data-id');
                const status = select.value;

                fetch('update_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        application_id: applicationId,
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Статус обновлен успешно!');
                    } else {
                        alert('Ошибка при обновлении статуса: ' + data.message);
                    }
                })
                .catch((error) => {
                    console.error('Ошибка:', error);
                });
            });
        });
    </script>
</body>

</html>
