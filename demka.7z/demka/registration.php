<?php
require_once 'db.php';

$username = $email = $password = $fullname = $phone = "";
$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $fullname = trim($_POST["fullname"]);
    $phone = trim($_POST["phone"]);

    // Валидация логина
    if (empty($username) || !preg_match("/^[А-Яа-яЁё]{6,}$/u", $username)) {
        $errors['username'] = "Логин обязателен, должен содержать минимум 6 кириллических символов.";
    } else {
        // Проверка уникальности логина
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM public.users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        if ($stmt->fetchColumn() > 0) {
            $errors['username'] = "Этот логин уже занят.";
        }
    }

    // Валидация ФИО
    if (empty($fullname) || !preg_match("/^[А-Яа-яЁё\s]+$/u", $fullname)) {
        $errors['fullname'] = "ФИО должно содержать только кириллицу и пробелы.";
    }

    // Валидация телефона
    if (empty($phone) || !preg_match("/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/", $phone)) {
        $errors['phone'] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX.";
    }

    // Валидация email
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Некорректный адрес электронной почты.";
    }

    // Валидация пароля
    if (empty($password) || strlen($password) < 6) {
        $errors['password'] = "Пароль должен содержать минимум 6 символов.";
    }

    // Если ошибок нет, сохраняем пользователя
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO public.users (username, fullname, phone, email, password) VALUES (:username, :fullname, :phone, :email, :password)";
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':username' => $username,
            ':fullname' => $fullname,
            ':phone' => $phone,
            ':email' => $email,
            ':password' => $hashed_password,
        ]);

        header("Location: avtorization.php"); 
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333;
        }

        header {
            background-color: #4a90e2;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        header img {
            height: 50px;
            margin-right: 20px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }

        .form-container {
            width: 350px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            color: #4a90e2;
            margin-bottom: 20px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: 94%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="tel"]:focus {
            border-color: #4a90e2;
            outline: none;
        }

        input[type="submit"] {
            background-color: #4a90e2;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin: 20px 0;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #357ab8;
        }

        .error {
            color: red;
            font-size: 0.9em;
            margin-top: -8px;
            margin-bottom: 10px;
        }

        .login-link {
            text-align: center;
            margin-top: 15px;
            color: #333;
        }

        .login-link a {
            color: #4a90e2;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #4a90e2;
            color: white;
            text-align: center;
            padding: 15px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="Логотип">
        <h1>Регистрация</h1>
    </header>

    <div class="container">
        <div class="form-container">
            <h2>Создайте аккаунт</h2>
            <form method="post" action="">
                <input type="text" name="username" placeholder="Логин"
                    value="<?php echo htmlspecialchars($username); ?>">
                <div class="error"><?php echo isset($errors['username']) ? $errors['username'] : ''; ?></div>

                <input type="text" name="fullname" placeholder="ФИО" value="<?php echo htmlspecialchars($fullname); ?>">
                <div class="error"><?php echo isset($errors['fullname']) ? $errors['fullname'] : ''; ?></div>

                <input type="tel" name="phone" placeholder="Телефон (+7(XXX)-XXX-XX-XX)"
                    value="<?php echo htmlspecialchars($phone); ?>" oninput="formatPhone(this)">
                <div class="error"><?php echo isset($errors['phone']) ? $errors['phone'] : ''; ?></div>

                <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>">
                <div class="error"><?php echo isset($errors['email']) ? $errors['email'] : ''; ?></div>

                <input type="password" name="password" placeholder="Пароль">
                <div class="error"><?php echo isset($errors['password']) ? $errors['password'] : ''; ?></div>

                <input type="submit" value="Зарегистрироваться">
            </form>
            <div class="login-link">
                <p>Уже есть аккаунт? <a href="avtorization.php">Войти</a></p>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Ваша компания. Все права защищены.</p>
    </footer>

    <script>
        function formatPhone(input) {
            // Удаляем все символы, кроме цифр
            let value = input.value.replace(/\D/g, '');

            // Проверяем, начинается ли номер с 7
            if (value.length > 0 && value[0] !== '7') {
                value = '7' + value; // добавляем 7 в начале
            }

            // Форматируем номер
            const formatted = value.replace(/(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})/, '+7(\$2)-\$3-\$4-\$5');

            // Ограничиваем длину ввода
            if (formatted.length > 17) {
                input.value = formatted.substring(0, 17);
            } else {
                input.value = formatted;
            }
        }
    </script>


</body>
</html>
