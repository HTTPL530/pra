<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: avtor.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $review = $_POST['review'];
    $reservation_date = $_POST['reservation_date'];
    $reservation_time = $_POST['reservation_time'];

    // Сохранение отзыва в базе данных
    $sql = "INSERT INTO public.reviews (user_id, reservation_date, reservation_time, review) VALUES (:user_id, :reservation_date, :reservation_time, :review)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $user_id,
        ':reservation_date' => $reservation_date,
        ':reservation_time' => $reservation_time,
        ':review' => $review
    ]);

    header("Location: history.php"); // Перенаправление обратно в историю заявок
    exit;
}

// Получение параметров из URL
$reservation_date = $_GET['reservation_date'] ?? '';
$reservation_time = $_GET['reservation_time'] ?? '';
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Оставить отзыв</title>
</head>

<body>
    <h2>Оставить отзыв</h2>
    <form method="POST">
        <input type="hidden" name="reservation_date" value="<?= htmlspecialchars($reservation_date) ?>" />
        <input type="hidden" name="reservation_time" value="<?= htmlspecialchars($reservation_time) ?>" />
        <label for="review">Ваш отзыв:</label><br>
        <textarea name="review" id="review" rows="4" required></textarea><br>
        <button type="submit">Отправить отзыв</button>
    </form>
</body>

</html>
