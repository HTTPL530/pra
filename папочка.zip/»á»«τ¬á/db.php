<?php
$dsn = "pgsql:host=localhost;port=5432;dbname=postgres";
$conn = new PDO($dsn, "postgres", "123");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>