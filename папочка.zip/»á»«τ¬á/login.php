<?php
session_start();
require_once('db.php');

$login = $_POST['login'];
$pass = $_POST['pass'];

try {
    // Ищем пользователя по логину
    $sql = "SELECT * FROM users WHERE login = :login";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':login', $login);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        // Проверяем пароль
        if (password_verify($pass, $user['password_hash'])) {
            // Успешная авторизация
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_surname'] = $user['surname'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];

            // Перенаправление без проверки на админа
            header("Location: cabinet.php");
            exit();
        } else {
            // Неверный пароль
            echo "<script>alert('Неверный пароль')</script>";
            require_once('authorization_page.php');
        }
    } else {
        // Пользователь не найден
        echo "<script>alert('Пользователь не найден')</script>";
        require_once('authorization_page.php');
    }
} catch (PDOException $e) {
    echo "Ошибка выполнения запроса: " . $e->getMessage();
}
?>